const express = require('express');
const fetch = require('node-fetch');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..', 'frontend', 'build')));

const WORKER_URL = process.env.WORKER_URL || 'http://localhost:5000/process';

app.post('/api/process', async (req, res) =>{
  const { url } = req.body;
  if(!url) return res.status(400).send('url required');
  try{
    const r = await fetch(WORKER_URL, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({url})
    });
    if(!r.ok){
      const txt = await r.text();
      return res.status(500).send('worker error: ' + txt);
    }
    const data = await r.json();
    return res.json(data);
  }catch(err){
    console.error(err);
    return res.status(500).send('internal error');
  }
});

app.get('*', (req,res)=>{
  res.sendFile(path.join(__dirname, '..', 'frontend', 'build', 'index.html'));
});

const port = process.env.PORT || 4000;
app.listen(port, ()=> console.log('Backend listening on', port));